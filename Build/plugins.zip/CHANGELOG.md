# 0.5.0

- Added a way to harass your friends