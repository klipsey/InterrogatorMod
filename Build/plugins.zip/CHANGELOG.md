# 0.6.2

- Sots

# 0.6.1

- Fixed networking issues

# 0.6.0

- Added a barrier and armor boost after killing a convicted target
- Made Convict ending time more responsive
- Lowered self damage slightly

# 0.5.6 

- Fixed self damage always applying for clients

# 0.5.5

- Fixed parts of mesh floating when it should be invisible (Might break skins sorry, new mdl entry is ExtraModel/meshExtra)

# 0.5.4

- Changed Guilty to grant buff immediately upon Interrogator taking damage
- Fixed Ancient Scepter not activating on all enemies if you were not targetting a guilty enemy when aquiring it
- Convict now properly supports activating on multiple enemies at once with individual durations for each conviction target
- Fixed sword not going away after Conviction
- Fixed Lysate Cell not giving duration for Conviction 0.5 per lysate

# 0.5.3

- Fixed attackspeed lowering dash duration
- Fixed icon for ancient scepter being missing

# 0.5.2

- Increased size of cleaver by 2x

# 0.5.1

- Change a single word in tokens

# 0.5.0

- Added a way to harass your friends