# 0.5.2

- Increased size of cleaver by 2x

# 0.5.1

- Change a single word in tokens

# 0.5.0

- Added a way to harass your friends